﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public class PromotionList
    {
        public int id;
        public string PromotionType, Descriptons, ImagePath, startDate, enddate, PdfPath,Url, MonthValue, Message, Status;
    }
   
}
