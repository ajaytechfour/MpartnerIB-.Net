﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public class Notification
    {
        public string Label { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public int Id { get; set; }
        public string Sharelink { get; set; }
        public string Error { get; set; }
        public string Status { get; set; }
    }
}
