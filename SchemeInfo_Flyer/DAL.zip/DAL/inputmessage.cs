﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public class inputmessage
    {
        public string Code { get; set; }
        public string des { get; set; }
    }
}
