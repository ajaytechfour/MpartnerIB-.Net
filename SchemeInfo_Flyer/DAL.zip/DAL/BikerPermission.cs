﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class BikerPermissionData
    {
        public string ModuleName{get;set;}
       
        public string Permission;
       
        public string ModuleImage;
        public string Message;
        public string Status;

        public string Monthlimit;
    }
}
