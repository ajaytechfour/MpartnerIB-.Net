﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public class ProductLevel_One
    {
        public int Id { get; set; }
        public string product_level_one { get; set; }
        public string message { get; set; }
    }
}
