﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class TargetvsAchievement
    {

       public string ItemId { get; set; }

        public string ItemName { get; set; }
        //public string ItemWireName { get; set; }
        //public string ItemFanName { get; set; }
        //public string ItemLightingName { get; set; }

        //public string ItemFanINRName { get; set; }
        //public string ItemWDName { get; set; }
        //public double CurrentMonthTargerWire { get; set; }
        //public double CurrentMonthTargerFan { get; set; }
        //public double CurrentMonthTargerLighting { get; set; }

        //public double CurrentMonthTargetfanINR { get; set; }
        //public double CurrentMonthTargetWD { get; set; }


        public double CurrentMonthTarget { get; set; }

        public double CurrentMonthAchivement{ get; set; }


        //public double CurrentMonthAchievementWire { get; set; }
        //public double CurrentMonthAchievementFan { get; set; }
        //public double CurrentMonthAchievementLighting { get; set; }

        //public double CurrentMonthAchievementfanINR { get; set; }
        //public double CurrentMonthAchievementWD { get; set; }

        /* Following properties added for CR dt.7/4/2016*/
        public double CurrentMonthSuppliedWire { get; set; }
        public double CurrentMonthSuppliedFan { get; set; }
        public double CurrentMonthSuppliedLighting { get; set; }

        public double CurrentMonthSuppliedfanINR { get; set; }

        public int Flag { get; set; }

        public int supplyflag { get; set; }
     
        public int TargetLimit { get; set; }

        public int Percentage { get; set; }

        //public int PercentageFan { get; set; }
        //public int PercentageWire { get; set; }
        //public int PercentageFanINR { get; set; }
        //public int PercentageLightening { get; set; }
        //public int PercentageWD { get; set; }
        public string Share_link { get; set; }

    
        
    }
}
