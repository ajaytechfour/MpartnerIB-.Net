﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;
namespace DAL
{
    public class BikerDAL
    {
        string Url = "http://50.62.56.149:5055/";
        public BikerDAL()
        {
            db = new BikerDataClassesDataContext();

            db.DeferredLoadingEnabled = false;
        }

        public BikerDataClassesDataContext db;

        OtpClient.ServiceSoapClient otpDb = new OtpClient.ServiceSoapClient();
        public inputmessage BikerLogInCreateOtp(string empid, string imeinumber, string osversion,
            string devicename, string appversion)
        {
            inputmessage msg = new inputmessage();
            try
            {
                System.Data.Linq.ISingleResult<MHrCreateOtpResult> mhrCreateOtpResult = db.MHrCreateOtp(empid, imeinumber, osversion, devicename, appversion);
                if (mhrCreateOtpResult != null)
                {
                    SMSbyWebservice sms = SMSbyWebservice.Instance;
                    var smsTemp = mhrCreateOtpResult.Where(m => m != null && !String.IsNullOrEmpty(m.Biker_Mob))
                    .Select(m => new
                    {
                        EmployeeId = m.Biker_Code,
                        MobileNumber = m.Biker_Mob,
                        OTP = m.otp,
                        Biker_Name = m.Biker_Name,
                        Status = m.Status,
                        Message = m.Message
                    }).FirstOrDefault();

                    if (smsTemp != null)
                    {
                        sms.EmployeeId = smsTemp.EmployeeId;
                        sms.MobileNumber = smsTemp.MobileNumber;
                        sms.OTP = smsTemp.OTP;
                        string returnValue = sms.SendSMS();
                        //string returnValue = otpDb.sendsms(sms.MobileNumber, BodyMessage(sms.Biker_Name, sms.OTP), sms.Biker_Name, "pass@1234");// 

                        msg.Code = smsTemp.Status;
                        msg.des = smsTemp.Message;
                        return msg;
                    }

                    //if (!String.IsNullOrEmpty(dt.Rows[0][1].ToString()))
                    //{
                    //    string body = BodyMessage(dt.Rows[0][1].ToString(), dt.Rows[0][4].ToString());
                    //    mailsql m2 = new mailsql(dt.Rows[0][2].ToString(), "not", "not", "Luminous_mobileApp One Time Password", body, "");
                    //    m2.sendMaildb();
                    //}
                }
                else
                {
                    msg.Code = "ERROR";
                    msg.des = "Invalid Employee";
                    return msg;
                }
            }
            catch (Exception ex)
            {
                LogException(ex, "BikerLogInCreateOtp, empid | " + empid + ", imeinumber | " + imeinumber + ", osversion | " + osversion + ", devicename | " + devicename + ", appversion | " + appversion);
            }
            return msg;
        }


        public inputmessage RetailerLogInCreateOtp(string empid, string imeinumber, string osversion,
           string devicename, string appversion)
        {
            inputmessage msg = new inputmessage();
            try
            {
                var Retailerexist = db.MHrRetailerOtps.Where(c => c.empid == empid).ToList();
                if (Retailerexist.Count == 0)
                {
                    System.Data.Linq.ISingleResult<MHrRetailerCreateOtpResult> mhrCreateOtpResult = db.MHrRetailerCreateOtp(empid, imeinumber, osversion, devicename, appversion);
                    if (mhrCreateOtpResult != null)
                    {
                        SMSbyWebservice sms = SMSbyWebservice.Instance;
                        var smsTemp = mhrCreateOtpResult.Where(m => m != null && !String.IsNullOrEmpty(m.Retailer_Mob))
                        .Select(m => new
                        {
                            EmployeeId = m.Retailer_Code,
                            MobileNumber = m.Retailer_Mob,
                            OTP = m.otp,
                            Retailer_Name = m.Retailer_Name,
                            Status = m.Status,
                            Message = m.Message
                        }).FirstOrDefault();

                        if (smsTemp != null)
                        {
                            sms.EmployeeId = smsTemp.EmployeeId;
                            sms.MobileNumber = smsTemp.MobileNumber;
                            sms.OTP = smsTemp.OTP;
                            string returnValue = sms.SendSMS();
                            //string returnValue = otpDb.sendsms(sms.MobileNumber, BodyMessage(sms.Biker_Name, sms.OTP), sms.Biker_Name, "pass@1234");// 

                            msg.Code = smsTemp.Status;
                            msg.des = smsTemp.Message;
                            return msg;
                        }

                        //if (!String.IsNullOrEmpty(dt.Rows[0][1].ToString()))
                        //{
                        //    string body = BodyMessage(dt.Rows[0][1].ToString(), dt.Rows[0][4].ToString());
                        //    mailsql m2 = new mailsql(dt.Rows[0][2].ToString(), "not", "not", "Luminous_mobileApp One Time Password", body, "");
                        //    m2.sendMaildb();
                        //}
                    }
                    else
                    {
                        msg.Code = "ERROR";
                        msg.des = "Invalid Employee";
                        return msg;
                    }
                }
                else
                {
                    msg.Code = "ERROR";
                    msg.des = "Location Already Updated";
                    return msg;
                }
            }
            catch (Exception ex)
            {
                LogException(ex, "RetailerLogInCreateOtp, RetailerID | " + empid + ", imeinumber | " + imeinumber + ", osversion | " + osversion + ", devicename | " + devicename + ", appversion | " + appversion);
            }
            return msg;
        }
        private void LogException(Exception ex, string createdBy)
        {
            try
            {
                if (ex != null)
                {
                    Logger log = new Logger { Message = ex.Message, StackTrace = ex.StackTrace, CreatedOn = DateTime.Now, CreatedBy = createdBy };
                    db.Loggers.InsertOnSubmit(log);
                    db.SubmitChanges();
                }
            }
            catch (Exception)
            {
            }
        }

        private string BodyMessage(string Biker_Name, string OTP)
        {
            return "Your one time password is " + OTP + ". It will  expire in 30 minutes";
        }

        public bool CheckRetailerAssigned(string BikerLoginId)
        {
            return true;
        }

        public inputmessage OTPAuthentication(string empid, string imeinumber,
            string osversion, string devicename, string otp, string appid, string devid, string ostype)
        {
            inputmessage msg = new inputmessage();
            try
            {
                System.Data.Linq.ISingleResult<MHrVarifyOtpNotificationResult> mhrVarifyOtpNotificationResult =
                        db.MHrVarifyOtpNotification(empid, imeinumber, osversion, devicename, otp, appid, devid, ostype);
                if (mhrVarifyOtpNotificationResult != null)
                {
                    inputmessage inputMessage = mhrVarifyOtpNotificationResult.Where(m => m != null)
                        .Select(m => new inputmessage { Code = m.Code, des = m.Message }).FirstOrDefault();
                    if (inputMessage != null)
                    {
                        msg.Code = inputMessage.Code;
                        msg.des = inputMessage.des;
                    }
                    else
                    {
                        msg.Code = inputMessage.Code;
                        msg.des = inputMessage.des;
                    }
                }
                else
                {
                    msg.Code = "ERROR";
                    msg.des = "Please try again";
                }
            }
            catch (Exception ex)
            {
                LogException(ex, "OTPAuthentication, empid | " + empid + ", imeinumber | " + imeinumber + ", osversion | " + osversion + ", devicename | " + devicename + ", otp | " + otp + ", appid | " + appid + ", devid | " + devid + ", ostype | " + ostype);
            }
            return msg;
        }


        public inputmessage RetailerOTPAuthentication(string empid, string imeinumber,
           string osversion, string devicename, string otp, string appid, string devid, string ostype)
        {
            inputmessage msg = new inputmessage();
            try
            {
                System.Data.Linq.ISingleResult<MHrretailerVarifyOtpNotificationResult> mhrVarifyOtpNotificationResult =
                        db.MHrretailerVarifyOtpNotification(empid, imeinumber, osversion, devicename, otp, appid, devid, ostype);
                if (mhrVarifyOtpNotificationResult != null)
                {
                    inputmessage inputMessage = mhrVarifyOtpNotificationResult.Where(m => m != null)
                        .Select(m => new inputmessage { Code = m.Code, des = m.Message }).FirstOrDefault();
                    if (inputMessage != null)
                    {
                        msg.Code = inputMessage.Code;
                        msg.des = inputMessage.des;
                    }
                    else
                    {
                        msg.Code = inputMessage.Code;
                        msg.des = inputMessage.des;
                    }
                }
                else
                {
                    msg.Code = "ERROR";
                    msg.des = "Please try again";
                }
            }
            catch (Exception ex)
            {
                LogException(ex, "RetailerOTPAuthentication, empid | " + empid + ", imeinumber | " + imeinumber + ", osversion | " + osversion + ", devicename | " + devicename + ", otp | " + otp + ", appid | " + appid + ", devid | " + devid + ", ostype | " + ostype);
            }
            return msg;
        }

        public List<DistDealerDetail> GetDistributors(string BikersLogInId)
        {
            List<DistDealerDetail> distDealerDetail = null;
            try
            {

                //System.Data.Linq.ISingleResult<SP_GetDistributors_By_BikersLogInIdResult> getDistributorModels = db.SP_GetDistributors_By_BikersLogInId(BikersLogInId);
                //if (getDistributorModels != null && getDistributorModels.Count() > 0)
                //    distDealerDetail = db.SP_GetDistributors_By_BikersLogInId(BikersLogInId).Select(m => new DistDealerDetail { ID = m.ID, Customer_Type = m.Customer_Type, Dis_Sap_Code = m.Dis_Sap_Code, Dis_Name = m.Dis_Name }).ToList();
                System.Data.Linq.ISingleResult<SP_GetDistributors_By_Beat_BikersLogInIdResult> getDistributorModels = db.SP_GetDistributors_By_Beat_BikersLogInId(BikersLogInId);
                if (getDistributorModels != null && getDistributorModels.Count() > 0)
                    distDealerDetail = db.SP_GetDistributors_By_Beat_BikersLogInId(BikersLogInId).Select(m => new DistDealerDetail { ID = m.ID, Customer_Type = m.Customer_Type, Dis_Sap_Code = m.Dis_Sap_Code, Dis_Name = m.Dis_Name }).ToList();
            }
            catch (Exception ex)
            {
                LogException(ex, "GetDistributors, BikersLogInId | " + BikersLogInId);
            }
            return distDealerDetail;
        }

        public List<Item> GetItems()
        {
            List<Item> items = null;
            try
            {
                System.Data.Linq.ISingleResult<SP_GetItemsResult> sp_GetItemsResult = db.SP_GetItems();
                if (sp_GetItemsResult != null && sp_GetItemsResult.Count() > 0)
                    items = db.SP_GetItems().Where(m => m.ID != 4).Select(m => new Item { ID = m.ID, ItemName = m.ItemName }).ToList();
            }
            catch (Exception ex)
            {
                LogException(ex, "GetItems");
            }
            return items;
        }

        public List<BeatDetail> GetBeatList(string BDistributorId, string BikersLogInId)
        {
            List<BeatDetail> beatDetails = null;
            try
            {
                System.Data.Linq.ISingleResult<SP_GetBeatList_By_DistId_BikerIdResult> sp_GetBeatList_By_DistId_BikerIdResult = db.SP_GetBeatList_By_DistId_BikerId(BDistributorId, BikersLogInId);
                if (sp_GetBeatList_By_DistId_BikerIdResult != null && sp_GetBeatList_By_DistId_BikerIdResult.Count() > 0)
                    beatDetails = db.SP_GetBeatList_By_DistId_BikerId(BDistributorId, BikersLogInId).Select(m => new BeatDetail { ID = m.ID, Code = m.Code, Name = m.Name }).ToList();
            }
            catch (Exception ex)
            {
                LogException(ex, "BikersLogInId | " + BikersLogInId + ",BDistributorId | " + BDistributorId);
            }
            return beatDetails;
        }

        //public List<RetailerDetail> GetRetailerList(string BeatId, string BDistributorId, string BikersLogInd, string SearchStringRetailerName)
        //{
        //    List<RetailerDetail> retailerDetails = null;
        //    try
        //    {
        //        System.Data.Linq.ISingleResult<SP_GetRetailerList_By_BeatId_DistId_BikerIdResult> sp_GetRetailerList_By_BeatId_DistId_BikerIdResult = db.SP_GetRetailerList_By_BeatId_DistId_BikerId(BeatId, BDistributorId, BikersLogInd, SearchStringRetailerName);
        //        if (sp_GetRetailerList_By_BeatId_DistId_BikerIdResult != null && sp_GetRetailerList_By_BeatId_DistId_BikerIdResult.Count() > 0)
        //            retailerDetails = db.SP_GetRetailerList_By_BeatId_DistId_BikerId(BeatId, BDistributorId, BikersLogInd, SearchStringRetailerName).Select(m => new RetailerDetail { ID = m.ID, Code = m.Code, Name = m.Name, Contact_Number = m.Contact_Number, Address = m.Address, State = m.State, CityArea = m.CityArea, Pin_Code = m.Pin_Code, Contact_person = m.Contact_person }).ToList();
        //    }
        //    catch (Exception ex)
        //    {
        //        LogException(ex, "GetRetailerList, " + "BikersLogInId | " + BikersLogInd + ",BDistributorId | " + BDistributorId + "BeatId | " + BeatId + "SearchStringRetailerName | " + SearchStringRetailerName);
        //    }
        //    return retailerDetails;
        //}
        public List<RetailerDetail> GetRetailerList(string BeatId, string BikersLogInd, string SearchStringRetailerName)
        {
            List<RetailerDetail> retailerDetails = null;
            try
            {
                System.Data.Linq.ISingleResult<SP_GetRetailerList_By_BeatId_DistId_BikerIdResult> sp_GetRetailerList_By_BeatId_DistId_BikerIdResult = db.SP_GetRetailerList_By_BeatId_DistId_BikerId(BeatId, BikersLogInd, SearchStringRetailerName);
                if (sp_GetRetailerList_By_BeatId_DistId_BikerIdResult != null && sp_GetRetailerList_By_BeatId_DistId_BikerIdResult.Count() > 0)
                    retailerDetails = db.SP_GetRetailerList_By_BeatId_DistId_BikerId(BeatId, BikersLogInd, SearchStringRetailerName).Select(m => new RetailerDetail { ID = m.ID, Code = m.Code, Name = m.Name, Contact_Number = m.Contact_Number, Address = m.Address, State = m.State, CityArea = m.CityArea, Pin_Code = m.Pin_Code, Contact_person = m.Contact_person }).ToList();
            }
            catch (Exception ex)
            {
                LogException(ex, "GetRetailerList, " + "BikersLogInId | " + BikersLogInd + "BeatId | " + BeatId + "SearchStringRetailerName | " + SearchStringRetailerName);
            }
            return retailerDetails;
        }


        /* Original:
         * 
         * 
        public List<RetailerDetail> GetRetailerListByName(string RetailerName)
        {
            List<RetailerDetail> retalersResult = null;
            List<RetailerDetail> retalers = db.RetailerDetails.Where(m => !String.IsNullOrEmpty(m.Active_Status)&& m.Active_Status == "Active" && m.Name.Contains(RetailerName)).ToList();
            if (retalers != null && retalers.Count > 0)
                retalersResult = retalers.Select(m =>
                new RetailerDetail
                {
                    ID = m.ID,
                    Code = m.Code,
                    Name = m.Name,
                    Contact_Number = m.Contact_Number,
                    Address = m.Address,
                    State = m.State,
                    CityArea = m.CityArea,
                    Pin_Code = m.Pin_Code
                }).ToList();
            return retalersResult;
        }
         */

        //public List<RetailerDetail> GetRetailerListByName(string bikersloginid, string searchstringretailername,string searchMob)
        //{
        //    List<RetailerDetail> retailerDetails = null;
        //    try
        //    {
        //        var sp_GetRetailerList_By_BikerIdResult = db.SP_GetRetailerList_By_BikerId(bikersloginid, searchstringretailername,searchMob);
        //        if (sp_GetRetailerList_By_BikerIdResult != null && sp_GetRetailerList_By_BikerIdResult.Count() > 0)
        //            retailerDetails = db.SP_GetRetailerList_By_BikerId(bikersloginid, searchstringretailername,searchMob)
        //                .Select(m => new RetailerDetail { ID = m.ID, Code = m.Code, Name = m.Name, Contact_Number = m.Contact_Number, Address = m.Address, State = m.State, CityArea = m.CityArea, Pin_Code = m.Pin_Code, Contact_person = m.Contact_person }).ToList();
        //    }
        //    catch (Exception ex)
        //    {
        //        LogException(ex, "GetRetailerListByName, " + "BikersLogInId | " + bikersloginid + "searchstringretailername | " + searchstringretailername);
        //    }
        //    return retailerDetails;
        //}


        public ResultMessage SaveNewOrder(string DestributorId, string RetailerId, string BeatId, string BikerLogInId,
            DateTime DateOfVisit, string Visisted, string Sold, string Status, List<OrderItemSave> OrderItemsSave, int OrderOfflineId) //int ItemsID, int RequiredQuantity, int SuppliedQuantity
        {
            ResultMessage message = new ResultMessage { Message = "Faliure", OrderId = 0 };
            try
            {
                int dist_ID = db.DistDealerDetails.Where(m => m.Dis_Sap_Code == DestributorId).Select(m => m.ID).FirstOrDefault();
                int Retailer_ID = db.RetailerDetails.Where(m => m.Code == RetailerId).Select(m => m.ID).FirstOrDefault();
                int Beat_ID = db.BeatDetails.Where(m => m.Code == BeatId).Select(m => m.ID).FirstOrDefault();

                OrderDetail orderDetails = new OrderDetail
                {
                    Date_Of_Visit = DateOfVisit,
                    Distributor_Id = dist_ID,
                    //Dis_Sap_Code = m.DistDealerDetail.Dis_Sap_Code,
                    //Dis_Name = m.DistDealerDetail.Dis_Name,
                    Beat_Id = Beat_ID,
                    //Beat_Code = m.BeatDetail.Code,
                    //Beat_Name = m.BeatDetail.Name,
                    Retailer_Id = Retailer_ID,
                    //Retailer_Code = m.RetailerDetail.Code,
                    //Retailer_Name = m.RetailerDetail.Name,
                    Visted = (!String.IsNullOrEmpty(Visisted) && Visisted.ToLower() == "yes") ? true : false,
                    Sold = (!String.IsNullOrEmpty(Sold) && Sold.ToLower() == "yes") ? true : false,
                    Status = Status,
                    Ordered_On = DateTime.Now,
                    Order_By = BikerLogInId
                };

                db.OrderDetails.InsertOnSubmit(orderDetails);
                db.SubmitChanges();

                if (OrderItemsSave != null && OrderItemsSave.Count > 0 && orderDetails.ID > 0)
                {
                    List<OrderItem> orderItems = new List<OrderItem>();
                    foreach (OrderItemSave OrderItemSaveObj in OrderItemsSave)
                    {
                        orderItems.Add(new OrderItem
                        {
                            Item_Id = OrderItemSaveObj.Item_Id,
                            Order_Id = orderDetails.ID,
                            Required_Quantity = OrderItemSaveObj.Required_Quantity,

                            Created_By = BikerLogInId,
                            Created_On = DateTime.Now,

                        });
                    }

                    db.OrderItems.InsertAllOnSubmit(orderItems);
                    db.SubmitChanges();
                }

                //int result = 0;
                //System.Data.Linq.ISingleResult<SP_SaveNewOrderResult> sp_SaveNewOrderResult = db.SP_SaveNewOrder(DestributorId, RetailerId, BeatId, BikerLogInId, DateOfVisit, Visisted, Sold, Status, ItemsID, RequiredQuantity, SuppliedQuantity);
                //if (sp_SaveNewOrderResult != null)
                //{
                //    SP_SaveNewOrderResult obj = sp_SaveNewOrderResult.FirstOrDefault();
                //    if(obj != null)
                //        result = obj.Column1;
                //}
                //if (result == 1)
                if (orderDetails.ID > 0)
                    message = new ResultMessage { Message = "Success", OrderId = orderDetails.ID };
            }
            catch (Exception ex)
            {

                message = new ResultMessage { Message = "Faliure", OrderId = 0 };
                LogException(ex, "SaveNewOrder, " + ",DestributorId | " + DestributorId + ",RetailerId | " + RetailerId + ",BeatId | " + BeatId + ",BikerLogInId | " + BikerLogInId + ",DateOfVisit | " + DateOfVisit.ToString() + ",Visisted | " + Visisted + ",Sold | " + Sold + ",Status | " + Status + ",OrderItemsSave | " + ((OrderItemsSave != null) ? OrderItemsSave.Count : 0));
            }
            return message;
        }

        public List<OrderIdBeatIdRetailId> GetOrders(string DestributorId, string BikerLogInId, string status, string RetailerId)
        {

            try
            {
                DistDealerDetail disDetail = null;
                if (!String.IsNullOrEmpty(DestributorId) && DestributorId.ToLower() != "null")
                    disDetail = db.DistDealerDetails.Where(m => m.Dis_Sap_Code == DestributorId).FirstOrDefault();
                RetailerDetail retDetail = null;
                if (!String.IsNullOrEmpty(RetailerId) && RetailerId.ToLower() != "null")
                    retDetail = db.RetailerDetails.Where(m => m.Code == RetailerId).FirstOrDefault();

                int distId = (disDetail != null) ? disDetail.ID : 0;
                int retId = (retDetail != null) ? retDetail.ID : 0;



                //&& k.Distributor_Id == ((distId == 0) ? k.Distributor_Id : distId)
                //&& k.Retailer_Id == ((retId == 0) ? k.Retailer_Id : retId)

                List<OrderDetailed> OrderDetails = db.OrderDetails
                    .Where(k => k.Distributor_Id == ((distId == 0) ? k.Distributor_Id : distId)
                    && k.Retailer_Id == ((retId == 0) ? k.Retailer_Id : retId)
                         && k.Order_By == BikerLogInId && k.Status.ToLower() == (status.ToLower() == "all" ? k.Status : status.ToLower()))
                    .Select(
                    m => new OrderDetailed
                    {
                        Order_ID = m.ID,
                        //Date_Of_Visit = m.Date_Of_Visit,
                        //Distributor_Id = m.Distributor_Id,
                        Dis_Sap_Code = m.DistDealerDetail.Dis_Sap_Code,
                        Dis_Name = m.DistDealerDetail.Dis_Name,
                        //Beat_Id = m.Beat_Id,
                        Beat_Code = m.BeatDetail.Code,
                        Beat_Name = m.BeatDetail.Name,
                        //Retailer_Id = m.Retailer_Id,
                        Retailer_Code = m.RetailerDetail.Code,
                        Retailer_Name = m.RetailerDetail.Name,

                        //Visted = m.Visted,
                        //Sold = m.Sold,
                        Status = m.Status,
                        Ordered_On = m.Ordered_On,
                        //Order_By = m.Order_By,
                        //Updated_On = m.Updated_On,
                        //Updated_By = m.Updated_By,
                        //OrderItems = m.OrderItems.Select(n => new OrderDetailedItem
                        //{
                        //    ID = n.ID,
                        //    Order_Id = n.Order_Id,
                        //    Item_Id = n.Item_Id,
                        //    ItemName = n.Item.ItemName,
                        //    Required_Quantity = n.Required_Quantity,
                        //    Pending_Quantity = (n.Required_Quantity - n.Supplied_Quantity),
                        //    Supplied_Quantity = n.Supplied_Quantity,
                        //    Created_On = n.Created_On,
                        //    Created_By = n.Created_By,
                        //    Updated_On = n.Updated_On,
                        //    Updated_By = n.Updated_By
                        //}).ToList()
                    }).OrderByDescending(c => c.Ordered_On).ToList();
                if (OrderDetails != null)
                {
                    List<OrderIdBeatIdRetailId> OrderIdBeatIdRetailIds = new List<OrderIdBeatIdRetailId>();
                    OrderIdBeatIdRetailIds.AddRange(OrderDetails.Select(m => new OrderIdBeatIdRetailId
                    {
                        Order_ID = m.Order_ID,
                        Beat_Code = m.Beat_Code,
                        Beat_Name = m.Beat_Name,
                        Retailer_Code = m.Retailer_Code,
                        Retailer_Name = m.Retailer_Name,
                        Destributor_Code = m.Dis_Sap_Code,

                        Destributor_Name = m.Dis_Name
                    }).Distinct().ToList());
                    return OrderIdBeatIdRetailIds;
                }
            }
            catch (Exception ex)
            {
                LogException(ex, "GetOrders, " + ",DestributorId | " + DestributorId + ",RetailerId | " + RetailerId + ",BikerLogInId | " + BikerLogInId + ",Status | " + status);
            }
            return new List<OrderIdBeatIdRetailId>();
        }

        public OrderDetailed OrderDetails(int OrderId)
        {


            OrderDetailed orderDetailed = null;
            try
            {
                orderDetailed = db.OrderDetails.Where(k => k.ID == OrderId).Select(
                       m => new OrderDetailed
                       {
                           Order_ID = m.ID,
                           //Date_Of_Visit = m.Date_Of_Visit,
                           //Distributor_Id = m.Distributor_Id,
                           Dis_Sap_Code = m.DistDealerDetail.Dis_Sap_Code,
                           Dis_Name = m.DistDealerDetail.Dis_Name,
                           //Beat_Id = m.Beat_Id,
                           Beat_Code = m.BeatDetail.Code,
                           Beat_Name = m.BeatDetail.Name,
                           //Retailer_Id = m.Retailer_Id,
                           Retailer_Code = m.RetailerDetail.Code,
                           Retailer_Name = m.RetailerDetail.Name,
                           //Visted = m.Visted,
                           //Sold = m.Sold,
                           Status = m.Status,
                           //Ordered_On = m.Ordered_On,
                           //Order_By = m.Order_By,
                           //Updated_On = m.Updated_On,
                           //Updated_By = m.Updated_By,
                           //OrderItems = 

                       }).FirstOrDefault();



                OrderDetail orderDetailTemp = db.OrderDetails
                    //.Include(k => k.OrderItems)
                    .Where(k => k.ID == OrderId).FirstOrDefault();


                //if (orderDetailTemp != null)
                //{
                List<OrderDetailedItem> orderDetailedItems = db.OrderItems
                    .Where(n => n.Order_Id == OrderId)
                    .Select(n => new OrderDetailedItem
                {
                    ID = n.ID,
                    Order_Id = n.Order_Id,
                    Item_Id = n.Item_Id,
                    ItemName = n.Item.ItemName,
                    Required_Quantity = ((n.Required_Quantity == null) ? 0 : n.Required_Quantity),
                    Pending_Quantity = (((n.Required_Quantity == null) ? 0 : n.Required_Quantity) - ((n.Supplied_Quantity == null) ? 0 : n.Supplied_Quantity)),
                    Supplied_Quantity = ((n.Supplied_Quantity == null) ? 0 : n.Supplied_Quantity),
                    Created_On = n.Created_On,
                    Created_By = n.Created_By,
                    Updated_On = n.Updated_On,
                    Updated_By = n.Updated_By
                }).ToList();


                if (orderDetailedItems != null && orderDetailedItems.Count > 0)
                {
                    foreach (OrderDetailedItem item in orderDetailedItems)
                    {
                        if (item.ItemName.ToLower() == "fan")
                        {
                            orderDetailed.Item_Id_Fan = (item.Item_Id == null) ? 0 : Convert.ToInt32(item.Item_Id);
                            orderDetailed.Item_Fan_Name = item.ItemName;
                            orderDetailed.Required_FanQuantity = (item.Required_Quantity == null) ? 0 : Convert.ToInt32(item.Required_Quantity);
                            orderDetailed.Pending_FanQuantity = (item.Pending_Quantity == null) ? ((orderDetailed.Status.ToLower() == "completed") ? 0 : orderDetailed.Required_FanQuantity) : Convert.ToInt32(item.Pending_Quantity);
                        }
                        else if (item.ItemName.ToLower() == "wire")
                        {
                            orderDetailed.Item_Id_Wire = (item.Item_Id == null) ? 0 : Convert.ToInt32(item.Item_Id);
                            orderDetailed.Item_Wire_Name = item.ItemName;
                            orderDetailed.Required_WireQuantity = (item.Required_Quantity == null) ? 0 : Convert.ToInt32(item.Required_Quantity);
                            orderDetailed.Pending_WireQuantity = (item.Pending_Quantity == null) ? ((orderDetailed.Status.ToLower() == "completed") ? 0 : orderDetailed.Required_FanQuantity) : Convert.ToInt32(item.Pending_Quantity);
                            orderDetailed.Flag = 1;
                        }

                        else if (item.ItemName.ToLower() == "faninr")
                        {
                            orderDetailed.Item_Id_FanINR = (item.Item_Id == null) ? 0 : Convert.ToInt32(item.Item_Id);
                            orderDetailed.Item_FanINR_Name = item.ItemName;
                            orderDetailed.Required_FanINRQuantity = (item.Required_Quantity == null) ? 0 : Convert.ToInt32(item.Required_Quantity);
                            orderDetailed.Pending_FanINRQuantity = (item.Pending_Quantity == null) ? ((orderDetailed.Status.ToLower() == "completed") ? 0 : orderDetailed.Required_FanQuantity) : Convert.ToInt32(item.Pending_Quantity);
                            orderDetailed.Flag = 0;
                        }
                        else if (item.ItemName.ToLower() == "lighting")
                        {
                            orderDetailed.Item_Id_Lighting = (item.Item_Id == null) ? 0 : Convert.ToInt32(item.Item_Id);
                            orderDetailed.Item_Light_Name = item.ItemName;
                            orderDetailed.Required_LightQuantity = (item.Required_Quantity == null) ? 0 : Convert.ToInt32(item.Required_Quantity);
                            orderDetailed.Pending_LightQuantity = (item.Pending_Quantity == null) ? ((orderDetailed.Status.ToLower() == "completed") ? 0 : orderDetailed.Required_FanQuantity) : Convert.ToInt32(item.Pending_Quantity);
                        }
                    }
                    //}
                }



            }
            catch (Exception ex)
            {
                LogException(ex, "OrderDetails, " + ",OrderId | " + OrderId);
            }

            return orderDetailed;
        }

        public string UpateOrder(List<OrderItemUpdate> orderItemUpdate, string status)
        {
            string message = "Faliure";
            try
            {
                OrderDetail orderDetails = db.OrderDetails.Where(m => m.ID == orderItemUpdate.FirstOrDefault().Order_Id).FirstOrDefault();
                if (orderDetails != null)
                {
                    orderDetails.Status = status;
                    orderDetails.Updated_On = DateTime.Now;
                    orderDetails.Updated_By = orderDetails.Order_By;

                    //db.OrderDetails.Attach(orderDetails);
                    db.SubmitChanges();

                    if (orderDetails != null && db.OrderItems != null)
                    {
                        List<OrderItem> orderItmeToUpdate = new List<OrderItem>();
                        List<OrderItem> orderItemsTemp = db.OrderItems.Where(m => m.Order_Id == orderDetails.ID).ToList();
                        foreach (OrderItem item in orderItemsTemp)
                        {

                            if (orderItemUpdate.Where(m => m.Item_Id == item.Item_Id).FirstOrDefault() != null)
                            {
                                item.Supplied_Quantity = ((item.Supplied_Quantity == null) ? 0 : item.Supplied_Quantity) + ((orderItemUpdate.Where(m => m.Item_Id == item.Item_Id).FirstOrDefault().Supplied_Quantity == null) ? 0 : orderItemUpdate.Where(m => m.Item_Id == item.Item_Id).FirstOrDefault().Supplied_Quantity);
                                item.Updated_On = DateTime.Now;
                                item.Updated_By = orderDetails.Order_By;
                            }

                            orderItmeToUpdate.Add(item);
                        }
                        if (orderItmeToUpdate != null && orderItmeToUpdate.Count > 0)
                        {
                            //db.OrderItems.AttachAll(orderItmeToUpdate);
                            db.SubmitChanges();
                            message = "Success";
                        }
                    }
                    message = "Success";
                }
            }
            catch (Exception ex)
            {
                message = "Faliure";
                LogException(ex, "UpateOrder, " + ",orderItemUpdate | " + ((orderItemUpdate != null) ? orderItemUpdate.Count : 0) + ",status | " + status);
            }
            return message;
        }

        public RetailerSuccess AddRetailer(string Name, string Contact_person, string State, string City, string Address, string Pin_Code, string Contact_Number, string Status, DateTime DateOfJoining, string BikersLoginId, string Beatid)
        {
            RetailerSuccess result = new RetailerSuccess { Message = "Faliure", RetailerId = "" };
            try
            {
                //if (String.IsNullOrEmpty(Code))
                //    return new RetailerSuccess { Message = "Code is required", RetailerId = 0 };
                if (String.IsNullOrEmpty(Name))
                    return new RetailerSuccess { Message = "Name is required", RetailerId = "" };
                if (String.IsNullOrEmpty(Contact_Number))
                    return new RetailerSuccess { Message = "Contact_Number is required", RetailerId = "" };

                /* Modified for CR dt. 7/4/2016 : BEGIN */

                if (IsContactNumberPresent(Contact_Number))
                {
                    return new RetailerSuccess { Message = "Duplicate Contact_Number", RetailerId = "" };
                }

                /* Modified for CR dt. 7/4/2016 : END */


                List<double> codes = db.RetailerDetails.Where(m => m.IsCreatedByBiker != null)
                    .Select(m => Convert.ToDouble(m.Code)).ToList();
                string code = string.Empty;
                if (codes != null && codes.Count > 0)
                    code = Convert.ToString(db.RetailerDetails.Where(m => m.IsCreatedByBiker != null)
                        .Select(m => Convert.ToDouble(m.Code)).ToList().Max() + 1);
                else
                    code = "6000000001";

                RetailerDetail retailerDetail = new RetailerDetail
                    {
                        Code = (!String.IsNullOrEmpty(code) ? code : "6000000001"),

                        Name = Name,
                        Contact_person = Contact_person,
                        State = State,
                        CityArea = City,
                        Address = Address,
                        Pin_Code = Pin_Code,
                        Contact_Number = Contact_Number,
                        Active_Status = Status,
                        Date_Of_Joining = DateOfJoining,
                        CreatedOn = DateTime.Now,
                        CreateBy = BikersLoginId,
                        IsCreatedByBiker = true,
                        BeatId = Beatid,
                        VerificationStatus = "0"

                    };

                db.RetailerDetails.InsertOnSubmit(retailerDetail);
                db.SubmitChanges();
                int retailerid = retailerDetail.ID;
                RetailBeatMapping retailerbeatmapp = new RetailBeatMapping
                {
                    Retailer_Id = retailerid,
                    Beat_Id = Convert.ToInt32(Beatid)
                };
                db.RetailBeatMappings.InsertOnSubmit(retailerbeatmapp);
                db.SubmitChanges();
                if (retailerDetail != null && retailerDetail.ID > 0)
                    result = result = new RetailerSuccess { Message = "Success", RetailerId = retailerDetail.Code };
                SendMail(retailerDetail);
            }
            catch (Exception ex)
            {
                LogException(ex, "AddRetailer, Name | " + ", Contact_person | " + Contact_person + ", State | " + State + ", City | " + City + ", Address | " + Address + ", Pin_Code | " + Pin_Code + ", Contact_Number | " + Contact_Number);
            }
            return result;
        }

        private bool IsContactNumberPresent(string Contact_Number)
        {
            return db.RetailerDetails.Any(m => m.Contact_Number.Equals(Contact_Number));
        }

        private void SendMail(RetailerDetail retailerDetail)
        {
            //Comma Seperated From and To Mail address will be provided in Web.Config file under AppSettings. To Address can be comma seperated mail address.
            System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
            List<string> toMailIds = ConfigurationSettings.AppSettings["ToMailId"].Split(',').ToList();
            foreach (string mailId in toMailIds)
            {
                message.To.Add(mailId.Trim());
            }
            message.Subject = "New Retailer added awaiting your approval";
            message.From = new System.Net.Mail.MailAddress(ConfigurationSettings.AppSettings["FromMailId"]);
            message.Body = "New Retailer has been added. <br/> Retailer Code : " + retailerDetail.Code + "<br/> Please login to Biker Management Portal to activate and Map to Beat and Biker.";
            message.IsBodyHtml = true;
            System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient(ConfigurationSettings.AppSettings["SMTPSERVER"]);
            smtp.Port = Convert.ToInt32(ConfigurationSettings.AppSettings["SMTPPORT"]);
            smtp.Credentials = new NetworkCredential(ConfigurationSettings.AppSettings["SMTPUSERNAME"], ConfigurationSettings.AppSettings["SMTPPASSWORD"]);
            smtp.Send(message);
        }

        public BikerTargetAchieved GetBikerMonthTarget(string BikerLoginId, int Month, int Year)
        {
            BikerTargetAchieved bikerTargetAchieved = new BikerTargetAchieved();
            try
            {
                List<BikerTarget> bikerTargets = db.BikerTargets.Join(db.BikerBoyDetails, m => m.BikerId, n => n.ID, (m, n) => new { m, n })
                    .Where(m => m.n.BB_Code == BikerLoginId
                    && m.m.MonthNumber == Month && m.m.YearNumber == Year).Select(m => m.m).ToList();
                List<OrderItem> orderItems = db.OrderItems.Where(m => (m.Created_On.Value.Year == Year || m.Updated_On.Value.Year == Year)
                    && (m.Created_On.Value.Month == Month || m.Updated_On.Value.Month == Month))
                    .Join(db.OrderDetails, m => m.Order_Id, n => n.ID, (m, n) => new { m, n })
                    .Where(p => p.n.Order_By == BikerLoginId).Select(p => p.m).ToList();

                bikerTargetAchieved.ItemFanName = "Fan";
                bikerTargetAchieved.ItemWireName = "Wire";
                bikerTargetAchieved.ItemLightingName = "Lighting";
                bikerTargetAchieved.ItemFanINRName = "FanINR";

                if (bikerTargets != null && bikerTargets.Count > 0)
                {
                    var Bikermonthyear = bikerTargets.Select(c => new { c.MonthNumber, c.YearNumber }).ToList();

                    foreach (var monthyear in Bikermonthyear)
                    {
                        if (monthyear.MonthNumber == 2 && monthyear.YearNumber == 2018)
                        {
                            //if (orderItems.Where(m => m.Item_Id == 1).FirstOrDefault() != null)
                            bikerTargetAchieved.CurrentMonthTargerFan = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 1).Sum(m => m.TargetQuantity));
                            //if (orderItems.Where(m => m.Item_Id == 2).FirstOrDefault() != null)
                            bikerTargetAchieved.CurrentMonthTargetfanINR = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 4).Sum(m => m.TargetQuantity));
                            // if (orderItems.Where(m => m.Item_Id == 3).FirstOrDefault() != null)
                            bikerTargetAchieved.CurrentMonthTargerLighting = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 3).Sum(m => m.TargetQuantity));
                            bikerTargetAchieved.Flag = 0;
                        }
                        else
                        {
                            //if (orderItems.Where(m => m.Item_Id == 1).FirstOrDefault() != null)
                            bikerTargetAchieved.CurrentMonthTargerFan = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 1).Sum(m => m.TargetQuantity));
                            //if (orderItems.Where(m => m.Item_Id == 2).FirstOrDefault() != null)
                            bikerTargetAchieved.CurrentMonthTargerWire = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 2).Sum(m => m.TargetQuantity));
                            // if (orderItems.Where(m => m.Item_Id == 3).FirstOrDefault() != null)
                            bikerTargetAchieved.CurrentMonthTargerLighting = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 3).Sum(m => m.TargetQuantity));
                            bikerTargetAchieved.Flag = 1;
                        }
                    }


                }
                if (orderItems != null && orderItems.Count > 0)
                {

                    if (orderItems.Where(m => m.Item_Id == 1).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthAchievementFan = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 1).Select(m => m.Required_Quantity).Sum());
                    if (orderItems.Where(m => m.Item_Id == 2).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthAchievementWire = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 2).Select(m => m.Required_Quantity).Sum());
                    if (orderItems.Where(m => m.Item_Id == 3).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthAchievementLighting = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 3).Select(m => m.Required_Quantity).Sum());
                    if (orderItems.Where(m => m.Item_Id == 4).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthAchievementfanINR = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 4).Select(m => m.Required_Quantity).Sum());
                    /* Modified for CR dt. 7/4/2016 : BEGIN */
                    if (orderItems.Where(m => m.Item_Id == 1).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthSuppliedFan = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 1).Select(m => m.Supplied_Quantity).Sum());
                    if (orderItems.Where(m => m.Item_Id == 2).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthSuppliedWire = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 2).Select(m => m.Supplied_Quantity).Sum());
                    if (orderItems.Where(m => m.Item_Id == 3).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthSuppliedLighting = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 3).Select(m => m.Supplied_Quantity).Sum());
                    if (orderItems.Where(m => m.Item_Id == 4).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthSuppliedfanINR = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 4).Select(m => m.Supplied_Quantity).Sum());
                    /* Modified for CR dt. 7/4/2016 : END */

                    if (bikerTargetAchieved.CurrentMonthSuppliedWire != 0 && bikerTargetAchieved.CurrentMonthSuppliedfanINR != 0)
                    {
                        bikerTargetAchieved.supplyflag = 2;
                    }
                    if (bikerTargetAchieved.CurrentMonthAchievementfanINR != 0 && bikerTargetAchieved.CurrentMonthAchievementWire != 0)
                    {
                        bikerTargetAchieved.supplyflag = 2;
                    }

                }
            }
            catch (Exception ex)
            {
                LogException(ex, "GetBikerMonthTarget, " + ", BikerLoginId | " + BikerLoginId + ", Month | " + Month + ", Year | " + Year);
            }

            return bikerTargetAchieved;

        }

        public string GetBikerNameByBikerCode(string BikerLoginId)
        {
            string bikerName = "";
            try
            {
                BikerBoyDetail bikerDetail = db.BikerBoyDetails.Where(m => m.BB_Code == BikerLoginId).FirstOrDefault();
                if (bikerDetail != null)
                {
                    bikerName = bikerDetail.BB_Name;
                }
            }
            catch (Exception ex)
            {
                LogException(ex, "GetBikerNameByBikerCode, " + ", BikerLoginId | " + BikerLoginId);
            }
            return bikerName;
        }
        public List<BeatDetail> GetBeatDetails(string BikerLoginId)
        {
            List<BeatDetail> beatDetails = null;
            try
            {
                //BikerBoyDetail bikerDetail = db.BikerBoyDetails.Where(m => m.BB_Code == BikerLoginId).FirstOrDefault();
                //if (bikerDetail != null)
                //{
                //    bikerName = bikerDetail.BB_Name;
                //}


                System.Data.Linq.ISingleResult<SP_GetBeatDetails_By_BikerIdResult> getbeatdetails = db.SP_GetBeatDetails_By_BikerId(BikerLoginId);
                if (getbeatdetails != null && getbeatdetails.Count() > 0)
                    beatDetails = db.SP_GetBeatDetails_By_BikerId(BikerLoginId).Select(m => new BeatDetail { ID = m.id, Name = m.Name, Code = m.Code }).ToList();
            }
            catch (Exception ex)
            {
                LogException(ex, "GetBeatDetails, " + ", BikerLoginId | " + BikerLoginId);
            }
            return beatDetails;
        }
        public List<State> getstate()
        {
            List<State> getdata = new List<State>();
            var Statedata = db.States.ToList();
            foreach (var data in Statedata)
            {
                State stdata = new State();
                stdata.StateID = data.StateID;
                stdata.StateName = data.StateName;
                getdata.Add(stdata);
            }
            return getdata;
        }

        //New Change By Ravi 05 March 2018//



        public inputmessage AddRetailerGPSLocation(string Retailerid, string GPSAddress, string Lat, string Long, string State, string City, string Country, string Pin, string Imeinumber)
        {
            inputmessage msg = new inputmessage();
            try
            {
                var Retailerexist = db.RetailerLocationDatas.Where(m => m.RetailerCode == Retailerid).ToList();

                if (Retailerexist.Count == 0)
                {
                    RetailerLocationData Retloc = new RetailerLocationData();

                    Retloc.RetailerCode = Retailerid;
                    Retloc.GPSAddress = GPSAddress;
                    Retloc.Lat = Lat;
                    Retloc.Long = Long;
                    Retloc.State = State;
                    Retloc.City = City;
                    Retloc.Country = Country;
                    Retloc.Pin = Pin;
                    Retloc.Imeinumber = Imeinumber;
                    Retloc.CreatedOn = DateTime.Now;
                    Retloc.CreatedBy = Retailerid;
                    db.RetailerLocationDatas.InsertOnSubmit(Retloc);
                    db.SubmitChanges();



                    var updateRetLocation = db.ExecuteCommand("update RetailerDetail set RetailerLocation='" + GPSAddress + "' where Code='" + Retailerid + "'");

                    msg.Code = "1";
                    msg.des = "Updated Successfully";
                }
                else
                {
                    msg.Code = "0";
                    msg.des = "Location Already Inserted";
                }




            }
            catch (Exception exc)
            {

                LogException(exc, "AddRetailerGPSLocation, " + ", RetailerID | " + Retailerid);
                msg.Code = "0";

                msg.des = "Some exception has occurred.";


            }
            return msg;
        }


        public List<BikerPermissionData> geBikerPermission()
        {
            List<BikerPermissionData> Bpermission = new List<BikerPermissionData>();
            try
            {


                var permissiondata = (from pd in db.BikerModules
                                      join od in db.BikerPermissions on pd.ModId equals od.ModuleId
                                      select new
                                      {
                                          pd.ModuleName,
                                          pd.ModuleImage,
                                          od.Permission,
                                      }).ToList();
                if (permissiondata.Count > 0)
                {
                    foreach (var data in permissiondata)
                    {
                        BikerPermissionData bpd = new BikerPermissionData();
                        bpd.ModuleName = data.ModuleName;
                        bpd.Monthlimit = "12";
                        bpd.ModuleImage = ConfigurationSettings.AppSettings["uaturl"].ToString() + "DrawerImages/" + data.ModuleImage; 
                        bpd.Permission = data.Permission.ToString();
                        bpd.Message = "Success";
                        Bpermission.Add(bpd);
                    }
                }
                else
                {
                    BikerPermissionData bpd = new BikerPermissionData();
                    bpd.ModuleName = "0";
                    bpd.ModuleImage = "0";
                    bpd.Monthlimit = "0";
                    bpd.Permission = "0";
                    bpd.Message = "Failure";
                    Bpermission.Add(bpd);
                }

            }
            catch (Exception exc)
            {
                LogException(exc, "geBikerPermission");
                BikerPermissionData bpd = new BikerPermissionData();
                bpd.ModuleName = "0";
                bpd.ModuleImage = "0";
                bpd.Monthlimit = "0";
                bpd.Permission = "0";
                bpd.Message = "Some exception occured";
                Bpermission.Add(bpd);
            }
            return Bpermission;
        }

        public List<RetailerDetail> GetRetailerListByBikerid(string BikersLogInd)
        {

            List<RetailerDetail> retailerDetails = new List<RetailerDetail>();
            try
            {

                var getretailer = db.RetailerDetails.Where(c => c.CreateBy == BikersLogInd).Select(c => new { c.Name, c.Contact_person, c.Contact_Number, c.Address, c.ID, c.Code, c.RetailerLocation,c.FirmName,c.AlternateMobileNo,c.Email,c.TinNo,c.GSTNo,c.ZipCode,c.ImageName,c.Pin_Code,c.State,c.CityArea }).ToList();
                if (getretailer.Count > 0)
                {

                    foreach (var data in getretailer)
                    {

                        RetailerDetail rd = new RetailerDetail();
                        rd.Name = data.Name;

                        if (data.Contact_person == null || data.Contact_person == "")
                        {
                            rd.Contact_person = "";
                        }
                        else
                        {
                            rd.Contact_person = data.Contact_person;
                        }


                        if (data.Address == null || data.Address == "")
                        {
                            rd.Address = "";
                        }
                        else
                        {
                            rd.Address = data.Address;
                        }
                        if (data.Contact_Number != null)
                        {
                            rd.Contact_Number = data.Contact_Number;
                        }
                        else
                        {
                            rd.Contact_Number = "0";
                        }
                        if (data.Contact_Number != null)
                        {
                            rd.Contact_Number = data.Contact_Number;
                        }
                        else
                        {
                            rd.Contact_Number = "0";
                        }
                        rd.ID = data.ID;
                        rd.Code = data.Code;

                        if (data.FirmName != null)
                        {
                            rd.FirmName = data.FirmName;
                        }
                        else
                        {
                            rd.FirmName = "0";
                        }
                        if (data.AlternateMobileNo != null)
                        {
                            rd.AlternateMobileNo = data.AlternateMobileNo;
                        }
                        else
                        {
                            rd.AlternateMobileNo = "0";
                        }
                        if (data.AlternateMobileNo != null)
                        {
                            rd.AlternateMobileNo = data.AlternateMobileNo;
                        }
                        else
                        {
                            rd.AlternateMobileNo = "0";
                        }

                        if (data.TinNo != null)
                        {
                            rd.TinNo = data.TinNo;
                        }
                        else
                        {
                            rd.TinNo = "0";
                        }
                        if (data.Pin_Code != null)
                        {
                            rd.Pin_Code = data.Pin_Code;
                        }
                        else
                        {
                            rd.Pin_Code = "0";
                        }


                        if (data.State != null)
                        {
                            rd.State = data.State;
                        }
                        else
                        {
                            rd.State = "0";
                        }
                        if (data.CityArea != null)
                        {
                            rd.CityArea = data.CityArea;
                        }
                        else
                        {
                            rd.CityArea = "0";
                        }
                        if(data.GSTNo!=null)
                        {
                            rd.GSTNo = data.GSTNo;
                        }
                        else
                        {
                            rd.GSTNo = "0";
                        }

                        if (data.Email != null)
                        {
                            rd.Email = data.Email;
                        }
                        else
                        {
                            rd.Email = "0";
                        }
                        if (data.ZipCode != null)
                        {
                            rd.ZipCode = data.ZipCode;
                        }
                        else
                        {
                            rd.ZipCode = data.ZipCode;
                        }

                        if (data.ImageName != null)
                        {
                            rd.ImageName = ConfigurationSettings.AppSettings["uaturl"].ToString() + "RetailerImage/" + data.ImageName;
                        }
                        else
                        {
                            rd.ImageName = "0";
                        }

                       
                        
                        if (data.RetailerLocation != null)
                        {
                            rd.RetailerLocation = data.RetailerLocation;
                        }
                        else
                        {
                            rd.RetailerLocation = "0";
                        }
                        retailerDetails.Add(rd);
                     
                    }
                }
                else
                {
                    RetailerDetail rd = new RetailerDetail();
                    rd.Name = "0";
                    rd.Contact_person = "0";
                    rd.Address = "0";
                    rd.Contact_Number = "0";
                    rd.ID = 0;
                    rd.Code = "0";
                    rd.RetailerLocation = "0";
                      rd.FirmName = "0";
                        rd.AlternateMobileNo = "0";
                        rd.TinNo = "0";
                        rd.GSTNo = "0";
                        rd.ZipCode = "0";
                        rd.ImageName = "0";
                        rd.Email = "0";
                    retailerDetails.Add(rd);
                }
            }
            catch (Exception ex)
               
            {
                LogException(ex, "GetRetailerList, " + "BikersLogInId | " + BikersLogInd);
            }
            return retailerDetails;
        }


        public ResultMessage SaveTrackAttendance(string userid, string checkinloc, string checkoutloc, string trackingflag, string imeinumber)
        {
            try
            {
                if (trackingflag == "1")
                {
                    var savetrackattendance = new TrackBikerAttendance();

                    savetrackattendance.BikerId = userid;
                    savetrackattendance.Date = DateTime.Now;
                    savetrackattendance.CheckinLoc = checkinloc;
                    savetrackattendance.CheckinTime = DateTime.Now;
                    savetrackattendance.CheckoutLoc = null;
                    savetrackattendance.CheckoutTime = null;
                    savetrackattendance.Imeinumber = imeinumber;
                    savetrackattendance.CreatedOn = DateTime.Now;
                    savetrackattendance.CreatedBy = userid;
                    savetrackattendance.Trackflag = 1;
                    db.TrackBikerAttendances.InsertOnSubmit(savetrackattendance);
                    db.SubmitChanges();

                    ResultMessage rm = new ResultMessage();
                    rm.Message = "CheckIn Successfull";
                    return rm;
                }
                else
                {
                    var savetrackattendance = new TrackBikerAttendance();

                    savetrackattendance.BikerId = userid;
                    savetrackattendance.Date = DateTime.Now;
                    savetrackattendance.CheckinLoc = null;
                    savetrackattendance.CheckinTime = null;
                    savetrackattendance.CheckoutLoc = checkoutloc;
                    savetrackattendance.CheckoutTime = DateTime.Now;
                    savetrackattendance.Imeinumber = imeinumber;
                    savetrackattendance.CreatedOn = DateTime.Now;
                    savetrackattendance.CreatedBy = userid;
                    savetrackattendance.Trackflag = 0;
                    db.TrackBikerAttendances.InsertOnSubmit(savetrackattendance);
                    db.SubmitChanges();
                    ResultMessage rm = new ResultMessage();
                    rm.Message = "CheckOut Successfull";
                    return rm;
                }
            }
            catch (Exception exc)
            {
                LogException(exc, "SaveTrackAttendance");
                ResultMessage rm = new ResultMessage();
                rm.Message = "Some exception has occurred";
                return rm;
            }

        }
        public List<GetTrackAttandance> getAttendenceList(string Bikerid)
        {
            List<GetTrackAttandance> attendencedetail = new List<GetTrackAttandance>();
            try
            {
                var attendancelist = db.TrackBikerAttendances.Where(m => m.BikerId == Bikerid).ToList();

                foreach (var data in attendancelist)
                {
                    GetTrackAttandance gtrack = new GetTrackAttandance();
                    gtrack.Bikerid = data.BikerId;
                    gtrack.Date = data.Date.ToString();
                    if (data.CheckinLoc == "" || data.CheckinLoc == null)
                    {
                        gtrack.CheckinLoc = "0";
                    }
                    else
                    {
                        gtrack.CheckinLoc = data.CheckinLoc;
                    }
                    if (data.CheckinTime == null)
                    {
                        gtrack.CheckInTime = "0";
                    }
                    else
                    {
                        gtrack.CheckInTime = data.CheckinTime.ToString();
                    }

                    if (data.CheckoutLoc == "" || data.CheckoutLoc == null)
                    {
                        gtrack.CheckoutLoc = "0";
                    }
                    else
                    {
                        gtrack.CheckoutLoc = data.CheckoutLoc;
                    }
                    if (data.CheckoutTime == null)
                    {
                        gtrack.CheckOutTime = "0";
                    }
                    else
                    {
                        gtrack.CheckOutTime = data.CheckoutTime.ToString();
                    }
                    gtrack.Flag = data.Trackflag.ToString();
                    gtrack.Message = "Success";
                    attendencedetail.Add(gtrack);

                }
            }
            catch (Exception exc)
            {
                LogException(exc, "getAttendenceList, " + ", BikerLoginId | " + Bikerid);
            }
            return attendencedetail;
        }

        public inputmessage AddRetailerNewVersion(string BikerId, string OwnerName, string FirmName, string MobileNo, string AlternateMobileNo, string Address, string City, string State, string Zipcode, string Email, string Tinno, string Gstno, string filename)
        {
            string FileName = filename;
            inputmessage msg = new inputmessage();
            try
            {
                List<double> codes = db.RetailerDetails.Where(m => m.IsCreatedByBiker != null)
                 .Select(m => Convert.ToDouble(m.Code)).ToList();
                string code = string.Empty;
                if (codes != null && codes.Count > 0)
                    code = Convert.ToString(db.RetailerDetails.Where(m => m.IsCreatedByBiker != null)
                        .Select(m => Convert.ToDouble(m.Code)).ToList().Max() + 1);
                else
                    code = "6000000001";

                RetailerDetail Retdetail = new RetailerDetail();
                Retdetail.Code = (!String.IsNullOrEmpty(code) ? code : "6000000001");
                Retdetail.Name = OwnerName;
                Retdetail.FirmName = FirmName;
                Retdetail.Contact_Number = MobileNo;

                if (AlternateMobileNo == "")
                {
                    Retdetail.AlternateMobileNo = "";
                }
                else
                {
                    Retdetail.AlternateMobileNo = AlternateMobileNo;
                }

                Retdetail.Address = Address;
                Retdetail.State = State;
                Retdetail.CityArea = City;
                Retdetail.ZipCode = Zipcode;
                Retdetail.Email = Email;
                Retdetail.TinNo = Tinno;
                Retdetail.GSTNo = Gstno;
                Retdetail.CreatedOn = DateTime.Now;
                Retdetail.CreateBy = BikerId;
                Retdetail.IsCreatedByBiker = true;






                if (filename != "")
                {
                    Retdetail.ImageName = filename;
                }
                else
                {
                    Retdetail.ImageName = "";

                }


                db.RetailerDetails.InsertOnSubmit(Retdetail);
                db.SubmitChanges();




                msg.Code = "1";
                msg.des = "Retailer Added Successfully";
            }
            catch (Exception exc)
            {
                msg.Code = "0";
                msg.des = "Some exception has occurred ";
                LogException(exc, "AddRetailerNewVersion");
            }
            return msg;
        }

        public inputmessage UpdateRetailerNewVersion(string Retailercode,string BikerId, string OwnerName, string FirmName, string MobileNo, string AlternateMobileNo, string Address, string City, string State, string Zipcode, string Email, string Tinno, string Gstno, string filename)
        {
            string FileName = filename;
            inputmessage msg = new inputmessage();
            try
            {
                

                RetailerDetail Retdetail = db.RetailerDetails.Single(c => c.Code == Retailercode);
                //Retdetail.Code = (!String.IsNullOrEmpty(code) ? code : "6000000001");
                Retdetail.Name = OwnerName;
                Retdetail.FirmName = FirmName;
                Retdetail.Contact_Number = MobileNo;

                if (AlternateMobileNo == "")
                {
                    Retdetail.AlternateMobileNo = "";
                }
                else
                {
                    Retdetail.AlternateMobileNo = AlternateMobileNo;
                }

                Retdetail.Address = Address;
                Retdetail.State = State;
                Retdetail.CityArea = City;
                Retdetail.ZipCode = Zipcode;
                Retdetail.Email = Email;
                Retdetail.TinNo = Tinno;
                Retdetail.GSTNo = Gstno;
                Retdetail.CreatedOn = DateTime.Now;
                Retdetail.CreateBy = BikerId;
                Retdetail.IsCreatedByBiker = true;






                if (filename != "")
                {
                    Retdetail.ImageName = filename;
                }
                else
                {
                    Retdetail.ImageName = "";

                }


                
                db.SubmitChanges();




                msg.Code = "1";
                msg.des = "Retailer Updated Successfully";
            }
            catch (Exception exc)
            {
                msg.Code = "0";
                msg.des = "Some exception has occurred ";
                LogException(exc, "AddRetailerNewVersion");
            }
            return msg;
        }


        public List<TargetvsAchievement> GetTargetVSAcheivement(string BikerId, string Imeinumber, string OS, string Version, int Month, int Year)
        {


            List<TargetvsAchievement> bikerTargetAchieved = new List<TargetvsAchievement>();
            try
            {
                if (Month != 0 && Year != 0)
                {
                    List<BikerTarget> bikerTargets = db.BikerTargets.Join(db.BikerBoyDetails, m => m.BikerId, n => n.ID, (m, n) => new { m, n })
                        .Where(m => m.n.BB_Code == BikerId
                        && m.m.MonthNumber == Month && m.m.YearNumber == Year).Select(m => m.m).ToList();
                    List<OrderItem> orderItems = db.OrderItems.Where(m => (m.Created_On.Value.Year == Year || m.Updated_On.Value.Year == Year)
                        && (m.Created_On.Value.Month == Month || m.Updated_On.Value.Month == Month))
                        .Join(db.OrderDetails, m => m.Order_Id, n => n.ID, (m, n) => new { m, n })
                        .Where(p => p.n.Order_By == BikerId).Select(p => p.m).ToList();


                    var Bikermonthyear = bikerTargets.Select(c => new { c.MonthNumber, c.YearNumber }).Distinct().ToList();

                    foreach (var monthyear in Bikermonthyear)
                    {

                        var itemlist = (from im in db.Items
                                        join oi in db.OrderItems on im.ID equals oi.Item_Id
                                        where (oi.Created_On.Value.Month == monthyear.MonthNumber || oi.Updated_On.Value.Month == monthyear.MonthNumber) && (oi.Created_On.Value.Year == monthyear.YearNumber || oi.Updated_On.Value.Year == monthyear.YearNumber)
                                        select new
                                        {
                                            im.ID,
                                            im.ItemName

                                        }).Distinct().ToList();
                        //var itemlist = db.Items.ToList();

                        foreach (var item in itemlist)
                        {
                            TargetvsAchievement Tva = new TargetvsAchievement();
                            Tva.CurrentMonthTarget = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == item.ID).Sum(m => m.TargetQuantity));
                            if (orderItems != null && orderItems.Count > 0)
                            {

                                if (orderItems.Where(m => m.Item_Id == item.ID).FirstOrDefault() != null)
                                {
                                    Tva.ItemId = item.ID.ToString();
                                    Tva.ItemName = item.ItemName;
                                    Tva.CurrentMonthAchivement = Convert.ToDouble(orderItems.Where(m => m.Item_Id == item.ID).Select(m => m.Required_Quantity).Sum

());
                                    if (Tva.CurrentMonthTarget == 0.0)
                                    {
                                        //  double percentFan = (double)(Tva.CurrentMonthAchivement * 100);

                                        Tva.Percentage = 0;
                                    }
                                    else
                                    {
                                        double percentFan = (double)(Tva.CurrentMonthAchivement * 100) / Tva.CurrentMonthTarget;
                                        Tva.Percentage = Convert.ToInt32(percentFan);
                                    }
                                }

                                else
                                {
                                    Tva.ItemId = item.ID.ToString();
                                    Tva.ItemName = item.ItemName;
                                    Tva.CurrentMonthTarget = 0;
                                    Tva.CurrentMonthAchivement = 0;
                                    // double percentWD = (double)(Tva.CurrentMonthAchivement * 100) / Tva.CurrentMonthTarget;
                                    Tva.Percentage = 0;
                                }



                                if (item.ID == 5)
                                {
                                    Tva.ItemId = item.ID.ToString();
                                    Tva.ItemName = item.ItemName;
                                    Tva.CurrentMonthTarget = 500;
                                    Tva.CurrentMonthAchivement = 300;
                                    double percentWD = (double)(Tva.CurrentMonthAchivement * 100) / Tva.CurrentMonthTarget;
                                    Tva.Percentage = Convert.ToInt32(percentWD);

                                }
                                Tva.Share_link = "http://biker.luminousindia.com";
                                Tva.TargetLimit = 600;

                            }

                            bikerTargetAchieved.Add(Tva);

                        }



                        // bikerTargetAchieved.Flag = 1;
                        // }
                    }




                }
                else
                {
                    List<BikerTarget> bikerTargets = db.BikerTargets.Join(db.BikerBoyDetails, m => m.BikerId, n => n.ID, (m, n) => new { m, n })
                        .Where(m => m.n.BB_Code == BikerId
                        && m.m.MonthNumber == System.DateTime.Now.Month && m.m.YearNumber == System.DateTime.Now.Year).Select(m => m.m).ToList();
                    List<OrderItem> orderItems = db.OrderItems.Where(m => (m.Created_On.Value.Year == System.DateTime.Now.Year || m.Updated_On.Value.Year ==

System.DateTime.Now.Year)
                        && (m.Created_On.Value.Month == System.DateTime.Now.Month || m.Updated_On.Value.Month == System.DateTime.Now.Month))
                        .Join(db.OrderDetails, m => m.Order_Id, n => n.ID, (m, n) => new { m, n })
                        .Where(p => p.n.Order_By == BikerId).Select(p => p.m).ToList();

                    //bikerTargetAchieved.ItemFanName = "Fan";
                    //bikerTargetAchieved.ItemWireName = "Wire";
                    //bikerTargetAchieved.ItemLightingName = "Lighting";
                    //bikerTargetAchieved.ItemFanINRName = "FanINR";
                    //bikerTargetAchieved.ItemWDName = "WD";

                    var Bikermonthyear = bikerTargets.Select(c => new { c.MonthNumber, c.YearNumber }).Distinct().ToList();

                    foreach (var monthyear in Bikermonthyear)
                    {

                        // var itemlist = db.Items.ToList();
                        var itemlist = (from im in db.Items
                                        join oi in db.OrderItems on im.ID equals oi.Item_Id
                                        where (oi.Created_On.Value.Month == System.DateTime.Now.Month || oi.Updated_On.Value.Month == System.DateTime.Now.Month) && (oi.Created_On.Value.Year == System.DateTime.Now.Year || oi.Updated_On.Value.Year == System.DateTime.Now.Year)
                                        select new
                                        {
                                            im.ID,
                                            im.ItemName

                                        }).Distinct().ToList();

                        foreach (var item in itemlist)
                        {
                            TargetvsAchievement Tva = new TargetvsAchievement();
                            Tva.CurrentMonthTarget = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == item.ID).Sum(m => m.TargetQuantity));

                            //bikerTargetAchieved.CurrentMonthTargerFan = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 1).Sum(m => m.TargetQuantity));
                            ////if (orderItems.Where(m => m.Item_Id == 2).FirstOrDefault() != null)
                            //bikerTargetAchieved.CurrentMonthTargerWire = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 2).Sum(m => m.TargetQuantity));
                            //// if (orderItems.Where(m => m.Item_Id == 3).FirstOrDefault() != null)
                            //bikerTargetAchieved.CurrentMonthTargerLighting = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 3).Sum(m => m.TargetQuantity));
                            //bikerTargetAchieved.CurrentMonthTargetfanINR = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 4).Sum(m => m.TargetQuantity));

                            //bikerTargetAchieved.CurrentMonthTargetWD = 500;


                            if (orderItems != null && orderItems.Count > 0)
                            {

                                if (orderItems.Where(m => m.Item_Id == item.ID).FirstOrDefault() != null)
                                {
                                    Tva.ItemId = item.ID.ToString();
                                    Tva.ItemName = item.ItemName;
                                    Tva.CurrentMonthAchivement = Convert.ToDouble(orderItems.Where(m => m.Item_Id == item.ID).Select(m => m.Required_Quantity).Sum

());
                                    if (Tva.CurrentMonthAchivement == 0.0)
                                    {
                                        // double percentFan = (double)(Tva.CurrentMonthAchivement * 100);
                                        Tva.Percentage = 0;
                                    }
                                    else
                                    {
                                        double percentFan = (double)(Tva.CurrentMonthAchivement * 100) / Tva.CurrentMonthTarget;
                                        Tva.Percentage = Convert.ToInt32(percentFan);
                                    }

                                }



                                if (item.ID == 5)
                                {
                                    if (orderItems.Where(m => m.Item_Id == 5).FirstOrDefault() != null)
                                    {
                                        Tva.ItemId = item.ID.ToString();
                                        Tva.ItemName = item.ItemName;
                                        Tva.CurrentMonthTarget = 500;
                                        Tva.CurrentMonthAchivement = 300;
                                        double percentWD = (double)(Tva.CurrentMonthAchivement * 100) / Tva.CurrentMonthTarget;
                                        Tva.Percentage = Convert.ToInt32(percentWD);
                                        Tva.Share_link = "http://biker.luminousindia.com";
                                        Tva.TargetLimit = 100;

                                    }
                                }
                                else
                                {
                                    Tva.Share_link = "http://biker.luminousindia.com";
                                }

                            }


                            bikerTargetAchieved.Add(Tva);

                        }

                    }



                }
            }
            catch (Exception ex)
            {
                LogException(ex, "GetTargetVSAcheivement, " + ", BikerLoginId | " + BikerId + ", Month | " + Month + ", Year | " + Year);
            }

            return bikerTargetAchieved;
        }




    }
}
