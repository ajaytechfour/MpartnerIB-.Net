namespace DAL
{
    partial class State
    {
    }
}
