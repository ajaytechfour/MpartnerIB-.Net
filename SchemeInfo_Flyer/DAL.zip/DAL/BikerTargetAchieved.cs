﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public class BikerTargetAchieved
    {
        public string ItemWireName { get; set; }
        public string ItemFanName { get; set; }
        public string ItemLightingName { get; set; }

        public string ItemFanINRName { get; set; }
        public double CurrentMonthTargerWire { get; set; }
        public double CurrentMonthTargerFan { get; set; }
        public double CurrentMonthTargerLighting { get; set; }

        public double CurrentMonthTargetfanINR { get; set; }
        public double CurrentMonthAchievementWire { get; set; }
        public double CurrentMonthAchievementFan { get; set; }
        public double CurrentMonthAchievementLighting { get; set; }

        public double CurrentMonthAchievementfanINR { get; set; }

        /* Following properties added for CR dt.7/4/2016*/
        public double CurrentMonthSuppliedWire { get; set; }
        public double CurrentMonthSuppliedFan { get; set; }
        public double CurrentMonthSuppliedLighting { get; set; }

        public double CurrentMonthSuppliedfanINR { get; set; }

        public int Flag { get; set; }

        public int supplyflag { get; set; }
    }
}
