﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace DAL
//{
//    public class SMSbyWebservice
//    {
//        public string Biker_Name { get; set; }
//        public string EmployeeId { get; set; }
//        public string MobileNumber { get; set; }
//        public string OTP { get; set; }
//        public string Status { get; set; }
//        public string Message { get; set; }
//    }
//}

