﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
  public  class Product_Details
    {
        public int ProductId { get; set; }
        public int CategoryId { get; set; }
        public string Image { get; set; }
        public string MaterialCode { get; set; }
        public string MaterialDesc { get; set; }
        public string FanCategory { get; set; }
        public string ModelName { get; set; }
        public string Sweep { get; set; }
        public string MRP { get; set; }
        public Nullable<DateTime> CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<DateTime> ModifyOn { get; set; }
        public string ModifyBy { get; set; }
        public string Message { get; set; }
        public int Quantity { get; set; }
    }
}
